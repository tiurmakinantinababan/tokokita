<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\AuthController;
use App\Http\Controllers\TentangController;
use App\Http\Controllers\ProdukController;
use App\Http\Controllers\BukuController;

Route::get('/', function () {
    return view('welcome');
});

//========================
// HALAMAN PUBLIK
//========================

Route::get('/tentang', [TentangController::class, 'index'])
    ->name('tentang');

Route::get('/produk', [ProdukController::class, 'index'])
    ->name('produk.index');

Route::get('/buku', [BukuController::class, 'index'])
    ->name('buku.index');

Route::get('/buku/detail/{id}', [BukuController::class, 'detail'])
    ->name('buku.detail');

Route::get('/buku/kategori/{genre}', [BukuController::class, 'kategori'])
    ->name('buku.kategori');

//========================
// LOGIN / LOGOUT
//========================

Route::get('/login', [AuthController::class, 'showLoginForm'])
    ->name('login');

Route::post('/login', [AuthController::class, 'authenticate'])
    ->name('login.process');

Route::post('/logout', [AuthController::class, 'logout'])
    ->name('logout');

//========================
// KHUSUS ADMIN (CRUD PRODUK & BUKU)
//========================

Route::middleware(['auth', 'role:admin'])->group(function () {

    // CRUD PRODUK
    Route::get('/produk/export/pdf', [ProdukController::class, 'exportPdf'])
        ->name('produk.export.pdf');

    Route::get('/produk/create', [ProdukController::class, 'create'])
        ->name('produk.create');

    Route::post('/produk', [ProdukController::class, 'store'])
        ->name('produk.store');

    Route::get('/produk/{id}/edit', [ProdukController::class, 'edit'])
        ->name('produk.edit');

    Route::put('/produk/{id}', [ProdukController::class, 'update'])
        ->name('produk.update');

    Route::delete('/produk/{id}', [ProdukController::class, 'destroy'])
        ->name('produk.destroy');


    // CRUD BUKU
    Route::get('/buku/create', [BukuController::class, 'create'])
        ->name('buku.create');

    Route::post('/buku', [BukuController::class, 'store'])
        ->name('buku.store');

    Route::get('/buku/{id}/edit', [BukuController::class, 'edit'])
        ->name('buku.edit');

    Route::put('/buku/{id}', [BukuController::class, 'update'])
        ->name('buku.update');

    Route::delete('/buku/{id}', [BukuController::class, 'destroy'])
        ->name('buku.destroy');

});

//====================================================
// ROUTE PEMBERSIH CACHE (DI LUAR MIDDLEWARE ADMIN)
//====================================================
Route::get('/clear-semua-cache', function() {
    \Artisan::call('config:clear');
    \Artisan::call('cache:clear');
    return "Cache Laravel Berhasil Dibersihkan Secara Total!";
});
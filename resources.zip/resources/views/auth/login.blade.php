@extends('layouts.app')

@section('title', 'Login')

@section('content')
<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-md-5">

            <div class="card shadow-sm border-0 mt-4">
                <div class="card-body p-4">

                    <h3 class="text-center font-weight-bold text-primary mb-4">
                        Login TokoKita
                    </h3>

                    @if ($errors->any())
                        <div class="alert alert-danger p-2 small" role="alert">
                            <ul class="mb-0 pl-3">
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif

                    <form action="{{ route('login.process') }}" method="POST">
                        @csrf

                        <div class="form-group mb-3">
                            <label for="email" class="font-weight-bold text-secondary small">Email</label>
                            <input type="email" name="email" id="email" class="form-control" placeholder="Masukkan Email" required>
                        </div>

                        <div class="form-group mb-4">
                            <label for="password" class="font-weight-bold text-secondary small">Password</label>
                            <input type="password" name="password" id="password" class="form-control" placeholder="Masukkan Password" required>
                        </div>

                        <button type="submit" class="btn btn-primary btn-block font-weight-bold tracking-wide py-2 shadow-sm">
                            Login
                        </button>
                    </form>

                </div>
            </div>
            </div>
    </div>
</div>
@endsection

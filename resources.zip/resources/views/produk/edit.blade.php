@extends('layouts.app')

@section('title','Edit Produk')

@section('content')

<div class="row mt-4">

    <div class="col-md-8 mx-auto">

        <div class="card shadow">

            <div class="card-header bg-warning">
                <h4>Edit Produk</h4>
            </div>

            <div class="card-body">

                <form action="{{ route('produk.update',$produk->id) }}"
                    method="POST"
                    enctype="multipart/form-data">

                    @csrf
                    @method('PUT')

                    <div class="mb-3">
                        <label>Nama Produk</label>

                        <input
                            type="text"
                            name="nama_produk"
                            value="{{ old('nama_produk',$produk->nama_produk) }}"
                            class="form-control">
                    </div>

                    <div class="mb-3">
                        <label>Harga</label>

                        <input
                            type="number"
                            name="harga"
                            value="{{ old('harga',$produk->harga) }}"
                            class="form-control">
                    </div>

                    <div class="mb-3">
                        <label>Deskripsi</label>

                        <textarea
                            name="deskripsi"
                            rows="3"
                            class="form-control">{{ old('deskripsi',$produk->deskripsi) }}</textarea>
                    </div>

                    <div class="mb-3">
                        <label>Stok</label>

                        <input
                            type="number"
                            name="stok"
                            value="{{ old('stok',$produk->stok) }}"
                            class="form-control">
                    </div>

                    <div class="mb-3">

                        <label>Foto Produk</label>

                        @if($produk->gambar)

                            <div class="mb-2">
                                <img
                                    src="{{ asset('storage/'.$produk->gambar) }}"
                                    width="200"
                                    class="img-thumbnail">
                            </div>

                        @endif

                        <input
                            type="file"
                            name="gambar"
                            class="form-control">

                        <small class="text-muted">
                            Kosongkan jika tidak ingin mengganti foto.
                        </small>

                    </div>

                    <button class="btn btn-success">
                        Simpan Perubahan
                    </button>

                    <a href="{{ route('produk.index') }}"
                        class="btn btn-secondary">
                        Kembali
                    </a>

                </form>

            </div>

        </div>

    </div>

</div>

@endsection

@extends('layouts.app')

@section('title', 'Daftar Produk')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4 mt-2">

    <h1 class="h3 mb-0">Daftar Produk</h1>

    <div>

        @auth

            @if(Auth::user()->role == 'admin')

                <a href="{{ route('produk.create') }}" class="btn btn-primary">
                    + Tambah Produk
                </a>

                <a href="{{ route('produk.export.pdf') }}" class="btn btn-danger">
                    📄 Export PDF
                </a>

            @endif

        @endauth

    </div>

</div>

<div class="row">

@forelse($data_produk as $item)

<div class="col-md-4 mb-4">

    <div class="card shadow-sm h-100">

        @if($item->gambar)

            <img
                src="{{ asset('storage/'.$item->gambar) }}"
                class="card-img-top"
                style="height:220px; object-fit:cover;">

        @else

            <img
                src="https://via.placeholder.com/600x400?text=Tidak+Ada+Foto"
                class="card-img-top"
                style="height:220px; object-fit:cover;">

        @endif

        <div class="card-body">

            <h5 class="fw-bold">
                {{ $item->nama_produk }}
            </h5>

            <h4 class="text-primary">
                Rp {{ number_format($item->harga,0,',','.') }}
            </h4>

            <p class="text-muted">
                {{ $item->deskripsi }}
            </p>

            @if($item->stok > 0)

                <span class="badge bg-success">
                    Stok : {{ $item->stok }}
                </span>

            @else

                <span class="badge bg-danger">
                    Stok Habis
                </span>

            @endif

        </div>

        <div class="card-footer bg-white">

            @auth

                @if(Auth::user()->role == 'admin')

                    <a href="{{ route('produk.edit',$item->id) }}"
                        class="btn btn-warning btn-sm">
                        Edit
                    </a>

                    <form
                        action="{{ route('produk.destroy',$item->id) }}"
                        method="POST"
                        class="d-inline">

                        @csrf
                        @method('DELETE')

                        <button
                            type="submit"
                            class="btn btn-danger btn-sm"
                            onclick="return confirm('Hapus produk ini?')">

                            Hapus

                        </button>

                    </form>

                @endif

            @endauth

        </div>

    </div>

</div>

@empty

<div class="col-12">

    <div class="alert alert-info">
        Belum ada produk.
    </div>

</div>

@endforelse

</div>

@endsection

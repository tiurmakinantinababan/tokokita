<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BukuController extends Controller
{
    // Halaman utama buku
    public function index()
    {
        return "Selamat datang di Katalog Buku Utama";
    }

    // Detail buku
   public function detail(int $id)
    {
        return "Anda sedang melihat detail buku dengan ID: " . $id;
    }

    // Kategori buku
   public function kategori(string $genre)
    {
        return "Menampilkan daftar buku dengan kategori: " . $genre;
    }

    // Validasi Update Buku (dipakai pada pertemuan selanjutnya)
  public function update(Request $request, int $id)
    {
        $validatedData = $request->validate([
            'judul_buku'   => 'required|min:5',
            'pengarang'    => 'required|alpha',
            'tahun_terbit' => 'required|numeric|min:1900|max:' . date('Y'),
        ], [
            'judul_buku.required'   => 'Judul buku wajib diisi!',
            'judul_buku.min'        => 'Judul buku minimal 5 karakter!',
            'pengarang.required'    => 'Nama pengarang wajib diisi!',
            'pengarang.alpha'       => 'Pengarang hanya boleh huruf!',
            'tahun_terbit.required' => 'Tahun terbit wajib diisi!',
            'tahun_terbit.numeric'  => 'Tahun terbit harus berupa angka!',
            'tahun_terbit.min'      => 'Tahun terbit minimal 1900!',
            'tahun_terbit.max'      => 'Tahun terbit tidak boleh melebihi tahun sekarang!',
        ]);

        return "Data buku ID " . $id . " berhasil divalidasi.";
    }
}

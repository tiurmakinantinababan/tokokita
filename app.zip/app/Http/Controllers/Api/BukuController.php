<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Buku;
use App\Http\Resources\BukuResource;
use Illuminate\Http\Request;

class BukuController extends Controller
{
    public function index()
    {
        // Mengambil semua data buku dari database
        $buku = Buku::all();

        // Mengembalikan data buku yang sudah diformat melalui BukuResource
        return BukuResource::collection($buku);
    }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Produk;
use Illuminate\Support\Facades\Storage;
use Barryvdh\DomPDF\Facade\Pdf;

class ProdukController extends Controller
{
    public function index()
    {
        $data_produk = Produk::all();

        return view('produk.index', compact('data_produk'));
    }

    // EXPORT PDF
    public function exportPdf()
    {
        $data_produk = Produk::all();

        // PAKSA DOMPDF TAHU LOKASI FOLDER PUBLIC DI HOSTINGAN & LOKAL VSCODE
        $dompdfConfig = config('dompdf');
        $dompdfConfig['public_path'] = base_path('../htdocs');
        config(['dompdf' => $dompdfConfig]);

        $pdf = Pdf::loadView('produk.pdf', compact('data_produk'));

        return $pdf->download('Daftar_Produk.pdf');
    }

    public function create()
    {
        return view('produk.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'nama_produk' => 'required|string|min:3|max:255',
            'harga' => 'required|numeric|min:1000',
            'stok' => 'required|integer|min:0',
            'deskripsi' => 'nullable|string',
            'gambar' => 'nullable|image|mimes:jpg,jpeg,png|max:2048'
        ]);

        if ($request->hasFile('gambar')) {
            $validated['gambar'] = $request
                ->file('gambar')
                ->store('produk', 'public');
        }

        Produk::create($validated);

        return redirect()->route('produk.index')
            ->with('success', 'Produk berhasil ditambahkan.');
    }

    public function edit(int $id)
    {
        $produk = Produk::findOrFail($id);

        return view('produk.edit', compact('produk'));
    }

    public function update(Request $request, int $id)
    {
        $validated = $request->validate([
            'nama_produk' => 'required|string|min:3|max:255',
            'harga' => 'required|numeric|min:1000',
            'stok' => 'required|integer|min:0',
            'deskripsi' => 'nullable|string',
            'gambar' => 'nullable|image|mimes:jpg,jpeg,png|max:2048'
        ]);

        $produk = Produk::findOrFail($id);

        if ($request->hasFile('gambar')) {

            if ($produk->gambar) {
                Storage::disk('public')->delete($produk->gambar);
            }

            $validated['gambar'] = $request
                ->file('gambar')
                ->store('produk', 'public');
        }

        $produk->update($validated);

        return redirect()->route('produk.index')
            ->with('success', 'Produk berhasil diperbarui.');
    }

    public function destroy(int $id)
    {
        $produk = Produk::findOrFail($id);

        if ($produk->gambar) {
            Storage::disk('public')->delete($produk->gambar);
        }

        $produk->delete();

        return redirect()->route('produk.index')
            ->with('success', 'Produk berhasil dihapus.');
    }
}